import streamlit as st

st.title("Registration Form")

with st.form("reg_form"):
    name = st.text_input("Enter your name : ")
    email = st.text_input("Enter your email : ")
    pwd = st.text_input("Enter your password : ", type="password")
    gender = st.radio("Select your gender",("Male","Female"))
    country = st.selectbox("Country", ["Ind","Ch","USA","UK"])
    submit = st.form_submit_button("Register")

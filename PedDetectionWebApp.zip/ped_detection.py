import streamlit as st
from PIL import Image
import pred_pedestrian

st.set_page_config(layout="wide")

st.title("Pedestrian Detection")

img = st.sidebar.selectbox(
    "Select Image", ('img_1.jpg','img_2.jpg')
)

input_image = "images/"+img
output_image = "output/"+img
image = Image.open(input_image)
st.image(image, width=700)

detect_btn = st.button("Detect Pedestrian")

if detect_btn:
    pred = pred_pedestrian.pred(input_image)
    st.write("Output Image...")
    # op_image = Image.open(pred)
    st.image(pred, width=700)
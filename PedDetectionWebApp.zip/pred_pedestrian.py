import torch
import torchvision
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from PIL import Image, ImageDraw
from torchvision.models.detection.mask_rcnn import MaskRCNNPredictor
from torchvision import transforms

NUM_CLASSES = 2

def get_segmentation(num_classes):
  model = torchvision.models.detection.maskrcnn_resnet50_fpn(pretrained=True)
  input_features = model.roi_heads.box_predictor.cls_score.in_features
  model.roi_heads.box_predictor = FastRCNNPredictor(input_features, num_classes)

  input_features_mask = model.roi_heads.mask_predictor.conv5_mask.in_channels
  hidden_layer = 256
  model.roi_heads.mask_predictor = MaskRCNNPredictor(input_features_mask,
                                                     hidden_layer,
                                                     num_classes)
  return model

def pred(input_image):
    device = torch.device('cpu')
    state_dict = torch.load('ped_detection.pth', map_location=device)
    loaded_model = get_segmentation(NUM_CLASSES)
    loaded_model.load_state_dict(state_dict)

    test_img = Image.open(input_image)

    transform_test = transforms.Compose([transforms.PILToTensor(),
                                        transforms.ConvertImageDtype(torch.float)])

    test_img_tensor = transform_test(test_img)

    loaded_model.eval()
    with torch.no_grad():
        prediction = loaded_model([test_img_tensor])

    # mask_img = Image.fromarray(prediction[0]['masks'][0,0].mul(255).byte().cpu().numpy())
    # x,y,w,h = prediction[0]['boxes'][2]
    test_img_op = Image.fromarray(test_img_tensor.mul(255).permute(1,2,0).byte().numpy())
    n_ped = len(prediction[0]['boxes'])
    for i in range(n_ped):
        x,y,w,h = prediction[0]['boxes'][i]
        draw = ImageDraw.Draw(test_img_op)
        draw.rectangle(((x, y), (w, h)), outline="red", width=5)
    return test_img_op